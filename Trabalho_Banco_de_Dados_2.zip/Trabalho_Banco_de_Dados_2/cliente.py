class ClientesDatabase:
    def __init__(self, database):
        self.db = database

    def criar_cliente(self, nome, endereco):
        query = "CREATE (:Cliente {nome: $nome, endereco: $endereco})"
        parameters = {"nome": nome, "endereco": endereco}
        self.db.execute_query(query, parameters)

    def atualizar_cliente(self, cliente_id, novo_nome, novo_endereco):
        query = """
        MATCH (c:Cliente) WHERE ID(c) = $cliente_id
        SET c.nome = $novo_nome, c.endereco = $novo_endereco
        """
        parameters = {"cliente_id": cliente_id, "novo_nome": novo_nome, "novo_endereco": novo_endereco}
        self.db.execute_query(query, parameters)

    def deletar_cliente(self, cliente_id):
        query = "MATCH (c:Cliente) WHERE ID(c) = $cliente_id DETACH DELETE c"
        parameters = {"cliente_id": cliente_id}
        self.db.execute_query(query, parameters)

    def ler_todos_clientes(self):
        query = "MATCH (c:Cliente) RETURN ID(c) AS cliente_id, c.nome AS nome, c.endereco AS endereco"
        results = self.db.execute_query(query)
        return [{"id": result["cliente_id"], "nome": result["nome"], "endereco": result["endereco"]} for result in results]

    def ler_cliente_por_id(self, cliente_id):
        query = "MATCH (c:Cliente) WHERE ID(c) = $cliente_id RETURN ID(c) AS cliente_id, c.nome AS nome, c.endereco AS endereco"
        parameters = {"cliente_id": cliente_id}
        results = self.db.execute_query(query, parameters)
        if results:
            result = results[0]
            return {"id": result["cliente_id"], "nome": result["nome"], "endereco": result["endereco"]}
        else:
            return None
